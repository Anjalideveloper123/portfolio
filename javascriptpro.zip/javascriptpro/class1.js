/*function clickhere(){
    document.getElementById("head").style.color="red"
}*/

// let a;
// const b;
// console.log(a)


//var name = "Anjali"
// console.log(name)

// let num1 = 60
//   let num2 = 100
//   let result = num1 / num2 * 100
//  console.log(`${result}%`)

// let num1 = 12
// let num2 = 13
// let result = num1 + num2
// console.log(result)

// let num1 = 67
// let num2 = 45
// let result = num1 - num2
// console.log(result)

// let num1 = 16
// let num2 = 11
// let result = num1* num2
// console.log(result)



// let dollar = 34
// let result = dollar * 72
// console.log(`${result}Rs`)

// let dollar = 30
// let result = dollar*72
// console.log(`${result}Euro`)



// let a =[123,23,346,567,6797,897,"dfgfh",true,12.4]
// console.log(typeof(a))
// console.log(a)

// let a = "hgyt5443@@@nkjnskjbhjsb"
// console.log(typeof(a))
// console.log(a)

// let a = 132562778.89
// console.log(typeof(a))
// console.log(a)

// let b = 6<7
// console.log(typeof(b))
// console.log(b)

// let a = [345, 799, 67889, 3567,"hjjhf",true,243.9]
// console.log(typeof(a))
// console.log(a)

// a =  prompt("Enter the operator : ")
// num1 = prompt("Enter the number : ")
// x = Number(num1)
// num2 = prompt("Enter the number : ")
// y = Number(num2)

// if(a == "+"){
//     alert(x + y)
// }



// switch(day = 2){
//     case 1:
//         console.log("Wednesday")
//     break
//     case 2:
//         console.log("Monday")
//     break
//     case 3:
//         console.log("Tuesday")  
//     break
//     default:
//         console.log("sorry no more day")          
// }

// let a = 10
// let b = 20
// let result = a**b
// console.log(result);



// let a = 20
// let b = 10
// let result = a % b
// console.log(result);

// let a = 50
// let b = 10
// let result = a==b
// console.log(result);


// let a = 30
// let b = 50 
// let c = a===b
// console.log(c);


// let a = 10
// let b = 10
// let c = a != b
// console.log(c)

// let num = 33
// let result = num >= 0 && num <= 33
// console.log(result)


// let num = 22
// let result = num >=10 && num <=22
// console.log(result)


// let num = 40

// if(num == 10 ){
//     console.log("if statement")
// }
// else if (num == 20){
//     console.log("else if statement")
// }
// else if(num == 30){
//     console.log("else if 2 statement")
// }

// else{
//     console.log("else statement")
// }

/*

0 - 33 -> f
33 - 50 -> d
50 - 70 -> c
70 - 90 -> b
90 - 100 -> a

*/
// let num = prompt("Enter your number: ")
// if(num >= 0 && num < 33){
//     alert("f grade")
// }
// else if(num >= 33 && num < 50){
//     alert("d grade")
// }
// else if(num >= 50  && num < 70){
//     alert("c grade")
// }
// else if(num >= 70 && num < 90){
//     alert("b grade")
// }
// else if(num >= 90 && num <= 100){
//     alert("a grade")
// }
// else{
//     alert("invalid number")
// }

// let a = 10000
// let b = 200 
// let c = 40

// if (a > b){
//     if (a > c){
//       console.log("the greatest value is", a)  
//     }
// }
// else if(b > a){
//     if (b > c ){
//         console.log("the greatest value is",b)
//     }
// }
// else if(c > a){
//     if (c > b){
//         console.log("the greatest value is",c)
//     }
// }

// let oper = prompt("enter the operator like + - * / % :")
// let a = Number(prompt("enter the number:"))
// let b = Number(prompt("enter second number:"))

// if(oper == "+"){
//     let result = a + b
//     alert(`the result is ${result}`)

// }
// if (oper ==  "-"){
//    let result = a - b
//    alert(`the result is ${result}`)
// }
// if (oper == "*"){
//     let result = a*b
//     alert(`the result is ${result}`)
// }
// if (oper == "%"){
//     let result = a%b
//     alert(`the result is ${result}`)
// }

// let num = prompt ("Enter number:")
// for (i = 1; i < 11; i++){
//     let result = num * i
//     console.log (`${num}* ${result}`)
// } 

// min()
// max()
// round()
// floor()
// ceil()
// random ()
// pow ()
// sqrt ()



// console.log(Math.floor(Math.random()*9000+999))
// console.log(Math.sqrt(81))

// let a = [12,3,445,67,8,6,7,2,5,7]
// a.splice(1,2)
// a.pop()
// delete a[2]
// a[0] = 123
// console.log(a)
// let a =[
//     [1,2,3,4],

//     [5,6,7,8],
//     [9,10,11,12],
//     [13,14,15,16,17,18,19]
// ]
// delete a[1][3]
// // a[2][2]  = 16
// console.log(a)

// console.log(a[3][6],a[3][4])

// let b =new  Array(1,2,3,4,5,6)

// console.log(typeof(b))


// a = [12,34,45,6,678,890,3,234,245,45,67,878,9,345,456,567,789,89,3,23,56,78]

for(i = 0; i < 50; i++){
    if(i % 4 != 3){
        continue
    }
    console.log(i)
}



